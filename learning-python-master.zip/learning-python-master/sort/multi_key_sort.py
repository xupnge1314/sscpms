#!/usr/bin/env python

# refs: http://coolshell.cn/articles/435.html


