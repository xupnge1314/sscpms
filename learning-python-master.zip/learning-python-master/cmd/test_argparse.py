
import argparse
parser = argparse.ArgumentParser(description="some information here")
args = parser.parse_args()
