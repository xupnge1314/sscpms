#!/usr/bin/env python
#-*- coding:utf-8 -*-

def test():
    print "Hello, I am Akagi201."

if __name__ == '__main__':
    test()
