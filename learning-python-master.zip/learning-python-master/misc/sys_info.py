#!/usr/bin/env python
import sys

print('Python %s on %s' % (sys.version, sys.platform))
