#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 由于正则表达式和 \ 会有冲突, 因此j, 当一个字符串使用了正则表达式后, 最好在前面加上'r'.

a = r"raw string\t tab \n"

print(a)