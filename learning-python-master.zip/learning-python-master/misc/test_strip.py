
def s(ss):
    return ss.strip('\x00')

l = '   sdfsdfsd   '
b = s(l)
print(b)

