#!/usr/bin/env python

s = [2*x for x in range(101) if x ** 2 > 3]

print s
