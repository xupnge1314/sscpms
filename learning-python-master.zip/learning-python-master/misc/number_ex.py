#!/usr/bin/env python
# coding: utf-8
#copyRight by heibanke

import math
math.pi
math.sqrt(80)
math.log10(2**1000)
math.pow(2,10)
math.factorial(9)


import random
random.random()
random.choice([1,2,3,4])
random.randint(0,10)
#random.uniform(a,b)
#random.gauss(mu,lamda)

