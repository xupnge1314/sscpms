#!/usr/bin/env python

"""Define basic data structure used in pprint examples.

"""

data = [(i, {'a': 'A',
             'b': 'B',
             'c': 'C',
             'd': 'D',
             'e': 'E',
             'f': 'F',
             'g': 'G',
             'h': 'H',
             })
        for i in xrange(3)
        ]
