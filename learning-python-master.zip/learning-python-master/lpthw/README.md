# Learn Python The Hard Way
* <http://learnpythonthehardway.org/book/>