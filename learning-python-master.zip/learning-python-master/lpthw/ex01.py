#!/usr/bin/env python

#Exercise 1: A Good First Program

print("Hello World!")
print "Hello Again"
print("I like Typing this.")
print("This is fun.")
print('Yay! Printing.')
print("I'd much rather you 'not'.")
print('I "said" do not touch this.')
print('This is another line!')
