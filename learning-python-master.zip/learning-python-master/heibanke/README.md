# 用Python做些事

## mooc地址
* <http://study.163.com/course/courseMain.htm?courseId=1000035>