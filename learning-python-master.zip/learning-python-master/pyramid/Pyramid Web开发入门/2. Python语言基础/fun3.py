def test(x):
    x = 5
    print 'x=', x


x = 3
test(x)
print 'x=', x
