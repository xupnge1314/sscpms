def max(a, b):
    if a > b:
        print a
    else:
        print b


max(1, 3)
max(4, 2)

