def echo(msg, times=1):
    print msg * times


echo('hello')
echo('test', 10)
