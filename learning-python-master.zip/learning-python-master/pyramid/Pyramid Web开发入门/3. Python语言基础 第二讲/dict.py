people = {
    'David': 'david@Hotmail.com',
    'Edward': 'edward@Gmail.com'
}

print 'David\'s email is %s' % people['David']

