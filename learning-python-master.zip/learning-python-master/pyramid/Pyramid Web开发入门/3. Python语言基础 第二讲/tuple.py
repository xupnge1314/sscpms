zoo = ('lion', 'wolf', 'bear')
print zoo
new_zoo = ('monkey', 'dolphin', zoo)
print new_zoo

