while True:
    s = raw_input('command:')
    if s == 'exit':
        break
    print 'Length of string is:', len(s)
else:
    print 'I won\'t be executed'
print 'over'
