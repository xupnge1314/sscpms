target1 = 53
target2 = 62
yours = int(raw_input('input a number please:'))
if yours == target1:
    print 'correct!'
elif yours == target2:
    print 'correct2'
else:
    print 'wrong'

