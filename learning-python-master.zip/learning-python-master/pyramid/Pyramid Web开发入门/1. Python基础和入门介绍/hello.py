def get_welcome(name):
    if name == 'bear':
        return 'Hello world!'

name = 'bear'
r = get_welcome(name)
print r
