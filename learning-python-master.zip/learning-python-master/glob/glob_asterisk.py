#!/usr/bin/env python

import glob

for name in glob.glob('dir/*'):
    print name
