var React = require('react');
var Todo = require('./components/Todo');

React.render(<Todo/>, document.getElementById("todo-container"));