from flask.ext.sqlalchemy import SQLAlchemy

db = SQLAlchemy()