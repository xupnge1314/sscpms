$(document).on('click', '.g-user', function () {
    console.log('user clicked');
});
