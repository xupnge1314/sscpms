from raven.contrib.flask import Sentry

sentry = Sentry()
