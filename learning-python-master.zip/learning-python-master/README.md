# learning-python
notes and codes while learning python

## version management
* pip
* virtualenv