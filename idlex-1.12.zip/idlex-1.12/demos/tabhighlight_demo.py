"""
    TabHighlight Demo

    Make sure "Highlight \t tabs" is checked in the Options menu.

    You will see tabs in this file highlighted as a checkered red rectangle.

								
	TabNanny will complain if you press F5.			
								
    
"""

if True:
	print('A tab is highlighted before this line')
	# more tabs
	# more tabs


for i in range(2):
	print(i)
        print(2*i)  # tab/space issue on this line - clearly visible
	print(3*i)


