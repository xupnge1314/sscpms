#
# The patch applied in http://bugs.python.org/issue1207589
# changes the structure of rmenu_specs in EditorWindow.py. This breaks a lot of extensions.
# This file is a re-factoring of rmenu code for other extensions to use.
#



