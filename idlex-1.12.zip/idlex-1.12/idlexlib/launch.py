

import idlexlib.idlexMain
idlexlib.idlexMain.main()


