<?php return array (
  15 => 
  array (
    'id' => 15,
    'name' => '网站页底关于我们等说明',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '1',
      'tagtemplate' => 'tag_category_foot_about.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  16 => 
  array (
    'id' => 16,
    'name' => '公司简介',
    'tagcontent' => '易通企业网站系统也称易通企业网站程序，是易通公司开发中国唯一可免费用于商业用途的营销型企业网站管理系统，系统前台生成html、完全符合SEO、同时有在线客服、潜在客户跟踪、便捷企业网站模板制作、搜索引擎推广等功能的企业网站系统。',
    'tagfrom' => 'define',
    'setting' => 
    array (
      'onlymodify' => '',
      'submit' => '提交',
      'catname' => '',
      'htmldir' => '',
    ),
  ),
  29 => 
  array (
    'id' => '29',
    'name' => '首页第一行翻页栏目一',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '1',
      'tagtemplate' => 'tag_category.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  30 => 
  array (
    'id' => 30,
    'name' => '首页第一行翻页栏目二',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'tagtemplate' => 'tag_category.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  31 => 
  array (
    'id' => 31,
    'name' => '首页第一行翻页栏目三',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '3',
      'tagtemplate' => 'tag_category.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  32 => 
  array (
    'id' => '32',
    'name' => '首页第一行翻页栏目四',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '14',
      'tagtemplate' => 'tag_category.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  33 => 
  array (
    'id' => '33',
    'name' => '首页第一行翻页栏目一左侧栏目图片说明',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '4',
      'tagtemplate' => 'tag_category_lanmutupian.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  34 => 
  array (
    'id' => '34',
    'name' => '首页第一行翻页栏目一右侧栏目图片说明',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '11',
      'tagtemplate' => 'tag_category_lanmutupian.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  35 => 
  array (
    'id' => '35',
    'name' => '首页第一行翻页栏目二图文4条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '2',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '12',
      'introduce_length' => '100',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '4',
      'tagtemplate' => 'tag_content_dl_dt_dd.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  36 => 
  array (
    'id' => '36',
    'name' => '首页第一行翻页栏目三图片6条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '3',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '8',
      'introduce_length' => '',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '6',
      'tagtemplate' => 'tag_content_i_pic.html',
      'submit' => '提交',
      'attr1' => '0',
    ),
  ),
  37 => 
  array (
    'id' => '37',
    'name' => '首页第一行翻页栏目四图片6条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '14',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'province_id' => '0',
      'city_id' => '0',
      'section_id' => '0',
      'length' => '8',
      'introduce_length' => '',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '6',
      'thumb' => 'on',
      'attr1' => '0',
      'tagtemplate' => 'tag_content_i_pic.html',
      'submit' => '提交',
    ),
  ),
  38 => 
  array (
    'id' => 38,
    'name' => '内页左侧第二行图片栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '4',
      'tagtemplate' => 'tag_category_url.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
);