<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<meta http-equiv="Expires" content="Fri, Jan 01 1900 00:00:00 GMT">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?php echo $this->title;?></title>
<link rel="stylesheet" type="text/css" href="<?php echo $this->baseUrl();?>/css/default.css">
</head>
<body>
    <?php echo $this->info;?>
</body>
</html>