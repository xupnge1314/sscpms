<?php

/**
 * 应用入口
 */

define('APP_PATH',      dirname(__FILE__).'/../');
define('SHOW_ERROR',    true);

//引入 Mini Framework 就是这么简单
require '../../Mini/Mini.php';