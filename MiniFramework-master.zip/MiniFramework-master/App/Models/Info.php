<?php
class Info
{
    public function getInfo()
    {
        return "<p>Hello World!</p>";
    }
}