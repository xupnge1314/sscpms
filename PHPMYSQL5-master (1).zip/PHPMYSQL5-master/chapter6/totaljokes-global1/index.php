<?php
include_once 'totaljokes-function.inc.php';

$totalJokes = totalJokes();

include 'output.html.php';
