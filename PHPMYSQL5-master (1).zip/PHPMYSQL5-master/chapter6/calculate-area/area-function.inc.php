<?php
function area($width, $height)
{
	return $width * $height;
}
