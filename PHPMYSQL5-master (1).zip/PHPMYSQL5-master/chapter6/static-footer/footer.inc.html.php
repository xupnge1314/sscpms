<p id="footer">
	The contents of this web page are copyright &copy; 1998&ndash;2012
	Example Pty. Ltd. All Rights Reserved.
</p>
